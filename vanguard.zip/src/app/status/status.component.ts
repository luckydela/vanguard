import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ServiceService} from '../service/service.service';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {
 
  organization:any[];
  agentsapr = {
    "":""
  }

  userdata;
 // searchcompany;
  viewagents: any;
 // searchorg: any;

  searchdata: any=[];
  constructor(private router: Router, private service: ServiceService) { }

  ngOnInit() {

    this.userdata=JSON.parse(localStorage.getItem('userdata'))


    var agents = JSON.stringify(this.agentsapr)

     this.service.getAgents(agents).subscribe(data=>{
    //this.org=data;
     console.log(data);
    this.viewagents=data;
    //this.searchdata= this.company;
   })
  }
}