import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ServiceService} from '../service/service.service';

@Component({
  selector: 'app-quotes',
  templateUrl: './quotes.component.html',
  styleUrls: ['./quotes.component.css']
})
export class QuotesComponent implements OnInit {

 
  organization:any[];
  quote = {
    "":""
  }
  userdata;
 // searchcompany;
  viewquote: any=[];
 // searchorg: any;

  searchdata: any=[];
  constructor(private router: Router, private service: ServiceService) { }

  ngOnInit() {
    this.userdata=JSON.parse(localStorage.getItem('userdata'))


    var quo = JSON.stringify(this.quote);

     this.service.getquote(quo).subscribe(data=>{
    //this.org=data;
     console.log(data);
    this.viewquote=data;
    //this.searchdata= this.company;
   })
  }
}
